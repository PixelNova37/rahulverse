
import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import AdminDashboard from './AdminDashboard';
import ProductManager from './ProductManager';
import ProfileSettings from './ProfileSettings';
import SystemMaintenance from './SystemMaintenance';

const AdminCommand: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [accessCode, setAccessCode] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsScanning(true);
    // Simulate biometric scan
    setTimeout(() => {
      if (accessCode === 'RAHUL_ROOT' || accessCode === '1234') {
        setIsAuthenticated(true);
      } else {
        alert('ACCESS_DENIED: Invalid credential key.');
      }
      setIsScanning(false);
    }, 1500);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="w-full max-w-md p-8 border-2 border-cyan-500/30 bg-slate-900 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500 animate-pulse"></div>
          <div className="text-center space-y-6">
            <div className="w-20 h-20 border-4 border-cyan-500 mx-auto rounded-full flex items-center justify-center relative">
              <span className={`text-4xl ${isScanning ? 'animate-ping' : ''}`}>🔐</span>
              {isScanning && (
                <div className="absolute inset-0 bg-cyan-400/20 animate-[scan_1s_ease-in-out_infinite] rounded-full"></div>
              )}
            </div>
            <div>
              <h2 className="font-sci text-2xl tracking-widest text-cyan-400">CORE_ACCESS_GATE</h2>
              <p className="text-[10px] text-slate-500 font-mono mt-1">RESTRICTED TO SUBJECT: RAHUL</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <input 
                type="password"
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                placeholder="ENTER_ACCESS_KEY..."
                className="w-full bg-black border border-cyan-500/30 p-4 text-cyan-400 font-mono focus:outline-none focus:border-cyan-500 text-center tracking-[0.5em]"
              />
              <button 
                type="submit"
                disabled={isScanning}
                className="w-full py-4 bg-cyan-500 text-slate-950 font-sci font-bold uppercase tracking-widest hover:bg-cyan-400 transition-all disabled:opacity-50"
              >
                {isScanning ? 'AUTHENTICATING...' : 'INITIATE_UPLINK'}
              </button>
            </form>
          </div>
          
          <style>{`
            @keyframes scan {
              0% { transform: scale(1); opacity: 0.5; }
              100% { transform: scale(1.5); opacity: 0; }
            }
          `}</style>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-8 py-6 animate-in fade-in duration-500">
      {/* Admin Sidebar */}
      <aside className="w-full lg:w-64 space-y-2">
        <div className="p-4 bg-cyan-500/10 border border-cyan-500/20 mb-6">
          <div className="text-[10px] font-sci text-cyan-400/60 uppercase">System Identity</div>
          <div className="font-sci text-lg text-cyan-400">ADMIN_CORE</div>
        </div>
        
        <AdminNavLink to="/admin" active={location.pathname === '/admin'}>DASHBOARD</AdminNavLink>
        <AdminNavLink to="/admin/products" active={location.pathname === '/admin/products'}>MARKET_MGMT</AdminNavLink>
        <AdminNavLink to="/admin/profile" active={location.pathname === '/admin/profile'}>PROFILE_CORE</AdminNavLink>
        <AdminNavLink to="/admin/maintenance" active={location.pathname === '/admin/maintenance'}>MAINTENANCE</AdminNavLink>
        
        <button 
          onClick={() => setIsAuthenticated(false)}
          className="w-full text-left px-4 py-3 font-sci text-xs text-red-500 hover:bg-red-500/10 border border-transparent hover:border-red-500/30 transition-all mt-8"
        >
          DISCONNECT_SESSION
        </button>
      </aside>

      {/* Admin Content Area */}
      <main className="flex-grow min-h-[60vh] bg-slate-900/50 border border-cyan-500/10 p-6 md:p-10 relative overflow-hidden">
        {/* Background Grid */}
        <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'linear-gradient(#22d3ee 1px, transparent 1px), linear-gradient(90deg, #22d3ee 1px, transparent 1px)', backgroundSize: '30px 30px' }}></div>
        
        <Routes>
          <Route path="/" element={<AdminDashboard />} />
          <Route path="/products" element={<ProductManager />} />
          <Route path="/profile" element={<ProfileSettings />} />
          <Route path="/maintenance" element={<SystemMaintenance />} />
        </Routes>
      </main>
    </div>
  );
};

const AdminNavLink: React.FC<{ to: string; active: boolean; children: React.ReactNode }> = ({ to, active, children }) => (
  <Link
    to={to}
    className={`block px-4 py-3 font-sci text-xs transition-all border-l-2 ${
      active 
        ? 'border-cyan-400 bg-cyan-400/10 text-cyan-400' 
        : 'border-transparent text-slate-500 hover:text-slate-300 hover:bg-slate-800'
    }`}
  >
    {children}
  </Link>
);

export default AdminCommand;
