
import React, { useState, useEffect } from 'react';

const AdminDashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="font-sci text-3xl text-cyan-400">COMMAND_DASHBOARD</h2>
          <p className="text-[10px] text-slate-500 font-mono mt-1 uppercase tracking-widest">
            UPLINK_STABILITY: 99.98% // NEURAL_LOAD: OPTIMAL // ENCRYPTION: ACTIVE
          </p>
        </div>
        <div className="text-right hidden md:block">
          <div className="text-[10px] font-sci text-cyan-400/40 uppercase">Global Node</div>
          <div className="text-xs font-mono text-cyan-400">PUNE_SERVER_01</div>
        </div>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard label="Total Visitors" value="1,402" trend="+12%" />
        <StatCard label="Revenue (INR)" value="₹1.2L" trend="+₹8k" />
        <StatCard label="Nova Queries" value="890" trend="STABLE" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Load Distribution - Radar Chart */}
        <div className="p-6 bg-slate-950 border border-cyan-500/10 space-y-6 flex flex-col min-h-[400px]">
          <div className="flex justify-between items-center">
            <h3 className="font-sci text-sm text-cyan-400 uppercase border-l-2 border-cyan-500 pl-3">Neural Load Distribution</h3>
            <span className="text-[8px] font-mono text-cyan-500/40 animate-pulse">LIVE_SYNC</span>
          </div>
          <div className="flex-grow flex items-center justify-center relative pt-4">
            <RadarChart />
          </div>
        </div>

        {/* System Activity - Pulse Monitor */}
        <div className="p-6 bg-slate-950 border border-cyan-500/10 space-y-6 flex flex-col min-h-[400px]">
          <div className="flex justify-between items-center">
            <h3 className="font-sci text-sm text-cyan-400 uppercase border-l-2 border-cyan-500 pl-3">Core Heartbeat Monitor</h3>
            <span className="text-[8px] font-mono text-cyan-500/40 uppercase tracking-tighter">Latency: 14ms</span>
          </div>
          <div className="flex-grow flex items-center justify-center pt-4">
            <PulseMonitor />
          </div>
        </div>
      </div>

      {/* Recent Activity Footer */}
      <div className="p-6 bg-slate-950 border border-cyan-500/10 space-y-4">
        <h3 className="font-sci text-sm text-cyan-400 border-b border-cyan-500/20 pb-2 uppercase">Global Neural Logs</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-2">
          <ActivityItem time="12:44" user="ID_4492" action="Purchased NEURAL_LINK_v1.0" />
          <ActivityItem time="10:12" user="ID_8810" action="Nova-X Inquiry: Subject Location" />
          <ActivityItem time="09:30" user="SYSTEM" action="Auto-Backup Initiated" />
          <ActivityItem time="04:20" user="ID_0001" action="AuthGate Login Successful" />
        </div>
      </div>
    </div>
  );
};

/* --- Custom Radar Chart Component --- */
const RadarChart: React.FC = () => {
  const [hovered, setHovered] = useState<number | null>(null);
  
  const labels = ["NEURAL", "MARKET", "UI", "UPLINK", "CACHE", "SECURITY"];
  const data = [75, 42, 88, 60, 55, 92]; // Percentages
  const size = 300;
  const center = size / 2;
  const radius = size * 0.4;

  const getCoordinates = (index: number, value: number) => {
    const angle = (Math.PI * 2 * index) / labels.length - Math.PI / 2;
    const r = (radius * value) / 100;
    return {
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle)
    };
  };

  const points = data.map((val, i) => {
    const coord = getCoordinates(i, val);
    return `${coord.x},${coord.y}`;
  }).join(' ');

  const gridLevels = [25, 50, 75, 100];

  return (
    <div className="relative w-full max-w-[300px] aspect-square flex items-center justify-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="overflow-visible">
        {/* Grid Circles */}
        {gridLevels.map((lvl) => (
          <polygon
            key={lvl}
            points={labels.map((_, i) => {
              const c = getCoordinates(i, lvl);
              return `${c.x},${c.y}`;
            }).join(' ')}
            fill="none"
            stroke="rgba(34, 211, 238, 0.1)"
            strokeWidth="1"
          />
        ))}

        {/* Axis Lines */}
        {labels.map((_, i) => {
          const c = getCoordinates(i, 100);
          return (
            <line
              key={i}
              x1={center}
              y1={center}
              x2={c.x}
              y2={c.y}
              stroke="rgba(34, 211, 238, 0.05)"
            />
          );
        })}

        {/* Data Area */}
        <polygon
          points={points}
          fill="rgba(34, 211, 238, 0.15)"
          stroke="rgba(34, 211, 238, 0.8)"
          strokeWidth="2"
          className="animate-pulse"
        />

        {/* Interactive Nodes */}
        {data.map((val, i) => {
          const c = getCoordinates(i, val);
          const labelPos = getCoordinates(i, 115);
          return (
            <g key={i} onMouseEnter={() => setHovered(i)} onMouseLeave={() => setHovered(null)}>
              <circle
                cx={c.x}
                cy={c.y}
                r={hovered === i ? 6 : 4}
                fill={hovered === i ? "#22d3ee" : "#020617"}
                stroke="#22d3ee"
                strokeWidth="2"
                className="transition-all duration-200 cursor-crosshair shadow-[0_0_10px_#22d3ee]"
              />
              <text
                x={labelPos.x}
                y={labelPos.y}
                textAnchor="middle"
                className="text-[8px] font-sci fill-cyan-500/40 uppercase pointer-events-none"
              >
                {labels[i]}
              </text>
              {hovered === i && (
                <g>
                   <rect x={c.x + 10} y={c.y - 15} width="35" height="15" fill="#020617" stroke="#22d3ee" strokeWidth="1" />
                   <text x={c.x + 14} y={c.y - 4} className="text-[9px] font-mono fill-cyan-400">{val}%</text>
                </g>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};

/* --- Custom Pulse Monitor Component --- */
const PulseMonitor: React.FC = () => {
  const [points, setPoints] = useState<number[]>(new Array(20).fill(50));
  
  useEffect(() => {
    const interval = setInterval(() => {
      setPoints(prev => {
        const next = [...prev.slice(1), 30 + Math.random() * 40];
        return next;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const width = 400;
  const height = 150;
  const step = width / (points.length - 1);
  const path = points.map((p, i) => `${i * step},${height - p}`).join(' L ');

  return (
    <div className="w-full h-full flex flex-col justify-between">
      <div className="relative w-full flex-grow border border-cyan-500/5 bg-black/40 overflow-hidden">
        {/* Grid Background */}
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'linear-gradient(#22d3ee 1px, transparent 1px), linear-gradient(90deg, #22d3ee 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
        
        <svg width="100%" height="100%" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
          <path
            d={`M 0,${height - points[0]} L ${path}`}
            fill="none"
            stroke="rgba(34, 211, 238, 0.8)"
            strokeWidth="2"
            className="transition-all duration-1000 ease-linear shadow-[0_0_10px_#22d3ee]"
          />
          {/* Scanning Line */}
          <line x1={width - 2} y1="0" x2={width - 2} y2={height} stroke="rgba(236, 72, 153, 0.4)" strokeWidth="1" className="animate-pulse" />
        </svg>
      </div>
      <div className="flex justify-between mt-4 font-mono text-[8px] text-slate-600">
        <span>T-20s</span>
        <span>REAL_TIME_FLUX_BUFFER</span>
        <span>NOW</span>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ label: string; value: string; trend: string }> = ({ label, value, trend }) => (
  <div className="p-5 border border-cyan-500/10 bg-slate-950/50 hover:border-cyan-500/30 transition-all group overflow-hidden relative">
    <div className="absolute top-0 right-0 w-8 h-8 border-t border-r border-cyan-500/20 group-hover:border-cyan-500 transition-colors"></div>
    <div className="text-[9px] text-slate-500 uppercase font-sci mb-2 tracking-widest">{label}</div>
    <div className="flex items-baseline justify-between">
      <div className="text-4xl font-sci font-bold text-cyan-100 group-hover:text-cyan-400 transition-colors">{value}</div>
      <div className={`text-[10px] font-mono ${trend.includes('+') ? 'text-green-500' : 'text-cyan-500'}`}>{trend}</div>
    </div>
  </div>
);

const ActivityItem: React.FC<{ time: string; user: string; action: string }> = ({ time, user, action }) => (
  <div className="flex gap-4 text-[9px] font-mono border-l border-cyan-500/20 pl-4 py-1.5 hover:bg-cyan-500/5 transition-colors">
    <span className="text-cyan-400/30">{time}</span>
    <span className="text-cyan-400/70">[{user}]</span>
    <span className="text-slate-400 truncate">{action}</span>
  </div>
);

export default AdminDashboard;
