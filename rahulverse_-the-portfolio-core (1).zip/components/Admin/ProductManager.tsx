
import React, { useState } from 'react';

const ProductManager: React.FC = () => {
  const [isAdding, setIsAdding] = useState(false);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="font-sci text-3xl text-cyan-400 uppercase">Market_Assets</h2>
          <p className="text-[10px] text-slate-500 font-mono mt-1">TOTAL_ASSETS: 04 // CATALOG_VERSION: 1.0.2</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="px-6 py-2 bg-cyan-500 text-slate-950 font-sci text-xs font-bold uppercase hover:bg-cyan-400 transition-all"
        >
          UPLOAD_NEW_ASSET
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b border-cyan-500/20 text-left text-[10px] font-sci text-cyan-400/60 uppercase">
              <th className="p-4">UID</th>
              <th className="p-4">Asset_Name</th>
              <th className="p-4">Category</th>
              <th className="p-4">Price</th>
              <th className="p-4">Stock</th>
              <th className="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="text-xs font-mono">
            <ProductRow id="RV-001" name="NEURAL_LINK_v1.0" cat="HARDWARE" price="₹45,000" stock={12} />
            <ProductRow id="RV-002" name="ENTROPY_PURGE" cat="ASSET" price="₹9,500" stock={5} />
            <ProductRow id="RV-003" name="DRONE_MOD_ALPHA" cat="SOFTWARE" price="₹24,999" stock={24} />
            <ProductRow id="RV-004" name="SHADER_PACK" cat="SOFTWARE" price="₹3,999" stock={999} />
          </tbody>
        </table>
      </div>

      {isAdding && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in zoom-in-95 duration-200">
           <div className="w-full max-w-lg bg-slate-900 border border-cyan-500 p-8 space-y-6">
              <h3 className="font-sci text-xl text-cyan-400 border-b border-cyan-500/20 pb-4">NEW_ASSET_METADATA</h3>
              <div className="grid grid-cols-2 gap-4">
                 <div className="space-y-1">
                    <label className="text-[9px] font-sci text-slate-500">UID</label>
                    <input type="text" placeholder="RV-XXX" className="w-full bg-black border border-cyan-500/20 p-3 text-cyan-400 font-mono text-sm" />
                 </div>
                 <div className="space-y-1">
                    <label className="text-[9px] font-sci text-slate-500">NAME</label>
                    <input type="text" placeholder="ASSET_NAME" className="w-full bg-black border border-cyan-500/20 p-3 text-cyan-400 font-mono text-sm" />
                 </div>
                 <div className="space-y-1">
                    <label className="text-[9px] font-sci text-slate-500">PRICE (₹)</label>
                    <input type="text" placeholder="0.00" className="w-full bg-black border border-cyan-500/20 p-3 text-cyan-400 font-mono text-sm" />
                 </div>
                 <div className="space-y-1">
                    <label className="text-[9px] font-sci text-slate-500">STOCK</label>
                    <input type="number" placeholder="0" className="w-full bg-black border border-cyan-500/20 p-3 text-cyan-400 font-mono text-sm" />
                 </div>
              </div>
              <div className="space-y-1">
                 <label className="text-[9px] font-sci text-slate-500">DESCRIPTION</label>
                 <textarea className="w-full bg-black border border-cyan-500/20 p-3 text-cyan-400 font-mono text-sm h-24"></textarea>
              </div>
              <div className="flex gap-4 pt-4">
                 <button onClick={() => setIsAdding(false)} className="flex-grow py-3 border border-cyan-500/30 text-cyan-400/60 font-sci text-xs hover:text-cyan-400 transition-all">CANCEL</button>
                 <button onClick={() => setIsAdding(false)} className="flex-grow py-3 bg-cyan-500 text-slate-950 font-sci text-xs font-bold uppercase hover:bg-cyan-400">REGISTER_ASSET</button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

const ProductRow: React.FC<{ id: string; name: string; cat: string; price: string; stock: number }> = ({ id, name, cat, price, stock }) => (
  <tr className="border-b border-cyan-500/5 hover:bg-cyan-500/5 transition-colors group">
    <td className="p-4 text-cyan-400/60">{id}</td>
    <td className="p-4 text-slate-100 uppercase">{name}</td>
    <td className="p-4 text-slate-400">{cat}</td>
    <td className="p-4 text-cyan-400">{price}</td>
    <td className="p-4 text-slate-500">{stock}</td>
    <td className="p-4 text-right space-x-4">
      <button className="text-cyan-400/40 hover:text-cyan-400 uppercase text-[10px] font-sci">Edit</button>
      <button className="text-red-500/40 hover:text-red-500 uppercase text-[10px] font-sci">Purge</button>
    </td>
  </tr>
);

export default ProductManager;
