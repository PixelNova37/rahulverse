
import React, { useState, useEffect } from 'react';

const ProfileSettings: React.FC = () => {
  const [isSaving, setIsSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  
  // Default data
  const DEFAULT_PROFILE = {
    fullName: 'Rahul',
    age: '20',
    designation: 'Student / Visionary',
    location: 'Pune, Maharashtra, India',
    email: 'rahulratho80@gmail.com',
    phone: '+91 9561848651',
    insta: 'rahul.bfx'
  };

  // State for form fields, initialized from local storage
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem('rahul_profile_core');
    return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
  });

  const handleInputChange = (field: string, value: string) => {
    setProfile((prev: any) => ({ ...prev, [field]: value }));
  };

  const handleUpdate = () => {
    setIsSaving(true);
    setShowSuccess(false);

    // Simulate writing to Neural Core
    setTimeout(() => {
      localStorage.setItem('rahul_profile_core', JSON.stringify(profile));
      setIsSaving(false);
      setShowSuccess(true);
      console.log("NEURAL_CORE_UPDATE: Successful", profile);
      
      // Hide success message after 3 seconds
      setTimeout(() => setShowSuccess(false), 3000);
    }, 1500);
  };

  const resetToDefaults = () => {
    if (window.confirm("CONFIRM_OVERRIDE: This will purge local profile cache. Proceed?")) {
      setProfile(DEFAULT_PROFILE);
      localStorage.removeItem('rahul_profile_core');
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-right-4 duration-300">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="font-sci text-3xl text-cyan-400 uppercase">SUBJECT_PROFILE_CORE</h2>
          <p className="text-[10px] text-slate-500 font-mono mt-1">PRIMARY_SUBJECT: RAHUL // CLEARANCE: OVERRIDE</p>
        </div>
        {showSuccess && (
          <div className="bg-green-500/20 border border-green-500 px-4 py-2 text-green-400 font-sci text-[10px] animate-bounce">
            CORE_DATA_SYNCHRONIZED_SUCCESSFULLY
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-6">
          <h3 className="font-sci text-sm text-cyan-400 uppercase border-b border-cyan-500/20 pb-2">Identity Matrix</h3>
          <div className="space-y-4">
             <InputField 
               label="FULL_NAME" 
               value={profile.fullName} 
               onChange={(val) => handleInputChange('fullName', val)} 
             />
             <InputField 
               label="AGE" 
               value={profile.age} 
               onChange={(val) => handleInputChange('age', val)} 
             />
             <InputField 
               label="DESIGNATION" 
               value={profile.designation} 
               onChange={(val) => handleInputChange('designation', val)} 
             />
             <InputField 
               label="LOCATION_NODE" 
               value={profile.location} 
               onChange={(val) => handleInputChange('location', val)} 
             />
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="font-sci text-sm text-cyan-400 uppercase border-b border-cyan-500/20 pb-2">Uplink Protocols</h3>
          <div className="space-y-4">
             <InputField 
               label="NEURAL_MAIL" 
               value={profile.email} 
               onChange={(val) => handleInputChange('email', val)} 
             />
             <InputField 
               label="VOICE_UPLINK" 
               value={profile.phone} 
               onChange={(val) => handleInputChange('phone', val)} 
             />
             <InputField 
               label="INSTA_NODE" 
               value={profile.insta} 
               onChange={(val) => handleInputChange('insta', val)} 
             />
             <div className="pt-4">
               <button 
                onClick={handleUpdate}
                disabled={isSaving}
                className={`w-full py-3 border-2 font-sci text-xs font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-3 ${
                  isSaving 
                    ? 'border-yellow-500 text-yellow-500 bg-yellow-500/10 cursor-wait' 
                    : 'border-cyan-500 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950'
                }`}
               >
                 {isSaving ? (
                   <>
                    <div className="w-3 h-3 border-2 border-yellow-500 border-t-transparent rounded-full animate-spin"></div>
                    SYNCING_CORE...
                   </>
                 ) : 'UPDATE_SUBJECT_DATA'}
               </button>
             </div>
          </div>
        </div>
      </div>

      <div className="p-6 border border-yellow-500/20 bg-yellow-500/5 space-y-4">
        <div className="flex items-center gap-4">
           <span className="text-2xl">⚠️</span>
           <h3 className="font-sci text-sm text-yellow-500 uppercase">DANGER_ZONE: SYSTEM_OVERRIDE</h3>
        </div>
        <p className="text-xs text-slate-500 font-mono">Changes to the identity matrix will propagate across all neural-net nodes including the public status interface.</p>
        <button 
          onClick={resetToDefaults}
          className="px-6 py-2 bg-red-600/20 border border-red-600/50 text-red-500 font-sci text-[10px] hover:bg-red-600 hover:text-white transition-all"
        >
          RESET_TO_DEFAULTS
        </button>
      </div>
    </div>
  );
};

const InputField: React.FC<{ label: string; value: string; onChange: (val: string) => void }> = ({ label, value, onChange }) => (
  <div className="space-y-1">
    <label className="text-[9px] font-sci text-slate-500 uppercase tracking-widest">{label}</label>
    <input 
      type="text" 
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full bg-slate-950 border border-cyan-500/10 p-3 text-cyan-400 font-mono text-sm focus:border-cyan-500 focus:outline-none transition-colors"
    />
  </div>
);

export default ProfileSettings;
