
import React from 'react';

const SystemMaintenance: React.FC = () => {
  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-right-4 duration-300">
      <div>
        <h2 className="font-sci text-3xl text-cyan-400 uppercase">SYSTEM_MAINTENANCE</h2>
        <p className="text-[10px] text-slate-500 font-mono mt-1">ENVIRONMENT: PRODUCTION // NODE_STATUS: OPERATIONAL</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h3 className="font-sci text-sm text-cyan-400 uppercase border-b border-cyan-500/20 pb-2">Live Neural Logs</h3>
          <div className="bg-black p-4 h-[300px] overflow-y-auto font-mono text-[10px] space-y-1 custom-scrollbar">
            <LogLine color="text-green-500" text="[SUCCESS] - Connection established to Google Gemini 3 Flash" />
            <LogLine color="text-cyan-500" text="[INFO] - Initializing Rahulverse Core v1.0.2" />
            <LogLine color="text-slate-500" text="[DEBUG] - Scanning assets for market cache..." />
            <LogLine color="text-yellow-500" text="[WARN] - High latency detected in Pune Node 4" />
            <LogLine color="text-green-500" text="[SUCCESS] - Data synchronization complete" />
            <LogLine color="text-slate-500" text="[DEBUG] - User ID_1102 logged out" />
            <LogLine color="text-pink-500" text="[DESTROY] - Entropy levels neutralized in profile core" />
            <LogLine color="text-cyan-500" text="[INFO] - Nova-X assistant ready" />
            <LogLine color="text-slate-500" text="[SYSTEM] - Monitoring background heartbeat..." />
            <LogLine color="text-green-500" text="[SUCCESS] - SSL handshake verified" />
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="font-sci text-sm text-cyan-400 uppercase border-b border-cyan-500/20 pb-2">UI Control Overrides</h3>
          <div className="space-y-6">
             <ToggleSwitch label="CRT_SCANLINES" active={true} />
             <ToggleSwitch label="GLITCH_FX" active={true} />
             <ToggleSwitch label="HUD_OVERLAY" active={true} />
             <ToggleSwitch label="MAINTENANCE_MODE" active={false} />
             <ToggleSwitch label="PUBLIC_UPLINK" active={true} />
          </div>
        </div>
      </div>
    </div>
  );
};

const LogLine: React.FC<{ text: string; color: string }> = ({ text, color }) => (
  <div className={`${color} opacity-80 hover:opacity-100 cursor-default`}>
    <span className="opacity-50">[{new Date().toLocaleTimeString()}]</span> {text}
  </div>
);

const ToggleSwitch: React.FC<{ label: string; active: boolean }> = ({ label, active }) => (
  <div className="flex justify-between items-center group">
    <span className="font-sci text-[10px] text-slate-500 group-hover:text-cyan-400 transition-colors uppercase">{label}</span>
    <button className={`w-12 h-6 rounded-full relative transition-colors ${active ? 'bg-cyan-500' : 'bg-slate-800'}`}>
      <div className={`absolute top-1 w-4 h-4 bg-slate-950 rounded-full transition-all ${active ? 'left-7' : 'left-1'}`}></div>
    </button>
  </div>
);

export default SystemMaintenance;
