
import React, { useState } from 'react';
import { useCart } from '../App';
import { Link } from 'react-router-dom';

const Cart: React.FC = () => {
  const { cart, removeFromCart, clearCart } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const tax = subtotal * 0.18; // GST 18%
  const total = subtotal + tax;

  const handleCheckout = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      clearCart();
    }, 2500);
  };

  if (isSuccess) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center space-y-8 animate-in zoom-in duration-500">
        <div className="w-24 h-24 border-4 border-green-500 rounded-full flex items-center justify-center mx-auto text-4xl animate-bounce">
          ✓
        </div>
        <h2 className="font-sci text-4xl text-green-400 glow-cyan">UPLINK_AUTHORIZED</h2>
        <p className="text-slate-400 font-mono tracking-widest">
          The assets have been registered to your neural ID. Check your Indian-node terminal for arrival coordinates.
        </p>
        <Link to="/market" className="inline-block px-8 py-3 bg-cyan-500 text-slate-950 font-sci font-bold uppercase tracking-widest">
          RETURN_TO_MARKET
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-12 py-10 animate-in fade-in slide-in-from-right-12 duration-500">
      <div className="text-center space-y-4">
        <h2 className="font-sci text-5xl font-black text-cyan-400 glow-cyan uppercase tracking-tighter">PAYLOAD_MANIFEST</h2>
        <p className="text-slate-400 font-mono text-xs uppercase tracking-widest">Current Buffer Status: {cart.length > 0 ? 'READY_FOR_TRANSMISSION' : 'EMPTY'}</p>
      </div>

      {cart.length === 0 ? (
        <div className="text-center py-20 border-2 border-dashed border-cyan-500/10">
          <p className="text-slate-500 font-sci mb-6">NO_DATA_IN_BUFFER</p>
          <Link to="/market" className="px-8 py-3 border border-cyan-500 text-cyan-400 font-sci text-xs hover:bg-cyan-500 hover:text-slate-950 transition-all">
            SCAN_FOR_ASSETS
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Item List */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map(item => (
              <div key={item.id} className="bg-slate-900/50 border border-cyan-500/20 p-6 flex items-center gap-6 group hover:border-cyan-500 transition-all">
                <div className="w-20 h-20 bg-black overflow-hidden border border-cyan-500/30">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" />
                </div>
                <div className="flex-grow">
                  <h3 className="font-sci text-lg text-cyan-100 uppercase">{item.name}</h3>
                  <div className="text-[10px] font-mono text-slate-500">QUANTITY: {item.quantity} // UID: {item.id}</div>
                </div>
                <div className="text-right space-y-2">
                  <div className="font-sci text-cyan-400">₹{item.price.toLocaleString('en-IN')}</div>
                  <button 
                    onClick={() => removeFromCart(item.id)}
                    className="text-[10px] font-sci text-red-500/60 hover:text-red-500 uppercase transition-colors"
                  >
                    [PURGE]
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Checkout Summary */}
          <div className="p-8 bg-slate-900 border-2 border-cyan-500/30 space-y-6 sticky top-24 h-fit">
            <h3 className="font-sci text-xl text-cyan-400 border-b border-cyan-500/20 pb-4">FINAL_CALCULATION</h3>
            
            <div className="space-y-3 font-mono text-sm">
              <div className="flex justify-between text-slate-400">
                <span>SUBTOTAL:</span>
                <span>₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>GST (18%):</span>
                <span>₹{tax.toLocaleString('en-IN')}</span>
              </div>
              <div className="h-px bg-cyan-500/20 my-4"></div>
              <div className="flex justify-between font-sci text-lg text-cyan-100">
                <span>TOTAL:</span>
                <span className="glow-cyan">₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button 
              onClick={handleCheckout}
              disabled={isProcessing}
              className="w-full py-5 bg-cyan-500 text-slate-950 font-sci font-black uppercase tracking-widest hover:bg-cyan-400 transition-all shadow-[0_0_20px_rgba(34,211,238,0.4)] disabled:opacity-50 flex items-center justify-center gap-4"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
                  AUTHORIZING...
                </>
              ) : (
                'CONFIRM_UPLINK'
              )}
            </button>

            <p className="text-[9px] text-slate-500 font-mono text-center italic">
              "By confirming, you execute an immutable contract within the Rahulverse Neural Net."
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;
