
import React from 'react';

const Contact: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto py-12 animate-in fade-in slide-in-from-bottom-12 duration-700">
      <div className="bg-slate-900 border border-cyan-500/30 rounded-lg overflow-hidden shadow-2xl">
        <div className="bg-cyan-500/20 p-3 border-b border-cyan-500/30 flex items-center justify-between">
          <div className="flex gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
            <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
          </div>
          <div className="text-[10px] font-sci text-cyan-400 tracking-widest">RAHULVERSE_SECURE_UPLINK</div>
          <div className="w-6"></div>
        </div>

        <div className="p-8 md:p-12 space-y-12">
          <div className="space-y-6">
            <h2 className="font-sci text-4xl md:text-5xl font-black">GET IN TOUCH.</h2>
            <p className="text-slate-400 font-mono">
              Ready to discover the world, invent the future, or destroy negativity? Establish a direct link below.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ContactLink 
              label="NEURAL_MAIL" 
              value="rahulratho80@gmail.com" 
              href="mailto:rahulratho80@gmail.com" 
              icon="📧"
            />
            <ContactLink 
              label="VOICE_UPLINK" 
              value="+91 9561848651" 
              href="tel:9561848651" 
              icon="📱"
            />
            <ContactLink 
              label="LOCATION_TAG" 
              value="PUNE, MAHARASHTRA, INDIA" 
              href="https://www.google.com/maps/search/Pune" 
              icon="📍"
            />
            {/* Special Social Link for Insta */}
            <ContactLink 
              label="INSTA_NODE_v2.0" 
              value="rah_l.bfx" 
              href="https://instagram.com/rah_l.bfx" 
              icon="📸"
              isSpecial
            />
          </div>

          <div className="border-t border-cyan-500/10 pt-10">
            <div className="p-6 bg-cyan-500/5 border border-cyan-500/20 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-1 text-center md:text-left">
                <div className="font-sci text-xl">DM TO JOIN THE COLLECTIVE</div>
                <div className="text-xs text-slate-500">Any one want to join me? Establish transmission now.</div>
              </div>
              <button className="px-8 py-3 bg-cyan-400 text-slate-950 font-sci font-bold uppercase tracking-widest hover:scale-105 transition-transform active:scale-95">
                SEND_ENCRYPTED_MESSAGE
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-12 text-center text-slate-600 font-mono text-[10px] uppercase tracking-widest">
        © 2024 RAHULVERSE_v1.0 // ALL RIGHTS RESERVED // DESIGNED FOR THE FUTURE
      </div>
    </div>
  );
};

const ContactLink: React.FC<{ label: string; value: string; href: string; icon: string; isSpecial?: boolean }> = ({ label, value, href, icon, isSpecial }) => (
  <a 
    href={href} 
    target="_blank" 
    rel="noopener noreferrer" 
    className={`group block p-5 bg-slate-950 border transition-all relative overflow-hidden ${
      isSpecial 
        ? 'border-pink-500 shadow-[0_0_15px_rgba(236,72,153,0.2)] hover:shadow-[0_0_25px_rgba(236,72,153,0.4)]' 
        : 'border-slate-800 hover:border-cyan-500'
    }`}
  >
    {isSpecial && (
      <div className="absolute top-0 right-0 px-2 py-0.5 bg-pink-500 text-white text-[7px] font-sci uppercase tracking-tighter animate-pulse">
        PRIORITY_UPLINK
      </div>
    )}
    <div className={`text-[9px] font-sci mb-2 tracking-[0.2em] ${isSpecial ? 'text-pink-400' : 'text-cyan-400/40'}`}>
      {label}
    </div>
    <div className="flex items-center gap-3">
      <span className={`text-2xl transition-all ${isSpecial ? 'grayscale-0 animate-bounce' : 'grayscale group-hover:grayscale-0'}`}>
        {icon}
      </span>
      <span className={`text-lg font-mono truncate transition-colors ${
        isSpecial 
          ? 'text-pink-100 glow-magenta hover:text-white' 
          : 'text-slate-300 group-hover:text-cyan-400'
      }`}>
        {value}
      </span>
    </div>
    {isSpecial && (
       <div className="absolute bottom-0 left-0 w-full h-[1px] bg-pink-500/50 animate-[ping_2s_infinite]"></div>
    )}
  </a>
);

export default Contact;
