
import React from 'react';

const Destroy: React.FC = () => {
  return (
    <div className="space-y-12 py-10 animate-in fade-in slide-in-from-left-12 duration-500">
       <div className="relative overflow-hidden">
          <h2 className="font-sci text-5xl md:text-7xl font-black text-pink-600 glow-magenta text-center hover-glitch cursor-default">DESTROY</h2>
          <div className="absolute top-1/2 left-0 w-full h-px bg-pink-600/20 -z-10"></div>
       </div>

       <div className="max-w-3xl mx-auto space-y-8 text-center">
          <p className="text-slate-400 font-mono text-sm uppercase tracking-[0.3em] leading-loose">
             "To create, one must first dismantle. To heal, one must first purge. Destruction is not an end, but a necessary purification."
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <TargetCard 
               target="NEGATIVITY" 
               status="NEUTRALIZING" 
               desc="Eliminating toxic mindsets and self-doubt. Refactoring internal code for high-vibrational performance." 
            />
            <TargetCard 
               target="STATIC_SYSTEMS" 
               status="DISMANTLING" 
               desc="Breaking down outdated societal norms and inefficient workflows that hinder human progress." 
            />
          </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatBox label="NEGATIVITY_PURGED" value="98.4%" color="text-pink-500" />
          <StatBox label="BARRIERS_BROKEN" value="1,240" color="text-pink-500" />
          <StatBox label="LEVEL_OF_INTENT" value="MAX" color="text-pink-500" />
       </div>

       <div className="p-10 border-2 border-dashed border-pink-500/20 bg-pink-500/5 text-center space-y-6 rounded-3xl relative overflow-hidden group">
          {/* Animated red glow on hover */}
          <div className="absolute inset-0 bg-pink-600/0 group-hover:bg-pink-600/10 transition-colors duration-500 pointer-events-none"></div>
          
          <h3 className="font-sci text-2xl text-pink-500 uppercase group-hover:scale-110 transition-transform">Want to burn the bridge with the past?</h3>
          <p className="text-slate-400 max-w-lg mx-auto">
             Join my collective. We are destroying the legacy of mediocracy. DMs are open for those ready to rebuild.
          </p>
          <button className="px-10 py-4 bg-pink-600 text-white font-sci font-bold uppercase tracking-widest hover:bg-pink-500 transition-colors shadow-[0_0_20px_rgba(219,39,119,0.4)] active:scale-95 transform hover-shake">
             INITIATE PURGE
          </button>
       </div>
    </div>
  );
};

const TargetCard: React.FC<{ target: string; status: string; desc: string }> = ({ target, status, desc }) => (
  <div className="p-6 border border-pink-500/20 bg-slate-900/40 text-left relative group overflow-hidden cursor-crosshair">
    {/* Targeting Crosshair Elements */}
    <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-pink-500 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:translate-x-2 group-hover:translate-y-2"></div>
    <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-pink-500 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:-translate-x-2 group-hover:translate-y-2"></div>
    <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-pink-500 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:translate-x-2 group-hover:-translate-y-2"></div>
    <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-pink-500 opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:-translate-x-2 group-hover:-translate-y-2"></div>

    <div className="text-[10px] font-sci text-pink-500/60 mb-1 group-hover:text-pink-400 transition-colors">{status}</div>
    <h3 className="font-sci text-xl mb-3 text-pink-500 group-hover:glow-magenta transition-all group-hover:translate-x-1">{target}</h3>
    <p className="text-slate-400 text-sm group-hover:text-slate-200 transition-colors">{desc}</p>
    
    {/* Animated scanning bar for Target Card */}
    <div className="absolute inset-0 bg-pink-600/5 translate-x-[-100%] group-hover:animate-[sweep_2s_ease-in-out_infinite] pointer-events-none"></div>

    <style>{`
      @keyframes sweep {
        0% { transform: translateX(-100%); }
        50% { transform: translateX(100%); }
        100% { transform: translateX(-100%); }
      }
    `}</style>
  </div>
);

const StatBox: React.FC<{ label: string; value: string; color: string }> = ({ label, value, color }) => (
  <div className="p-4 bg-slate-900 border border-slate-800 text-center hover:border-pink-500/50 transition-colors group">
    <div className="text-[9px] text-slate-500 uppercase font-sci mb-1 group-hover:text-pink-400/60 transition-colors">{label}</div>
    <div className={`text-3xl font-sci font-black ${color} group-hover:scale-110 transition-transform`}>{value}</div>
  </div>
);

export default Destroy;
