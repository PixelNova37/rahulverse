
import React from 'react';

const Discover: React.FC = () => {
  return (
    <div className="space-y-12 py-10 animate-in fade-in zoom-in duration-500">
      <div className="text-center space-y-4">
        <h2 className="font-sci text-5xl md:text-7xl font-black text-cyan-400 glow-cyan">DISCOVER</h2>
        <p className="text-slate-400 max-w-2xl mx-auto font-mono text-sm uppercase tracking-widest">
          Scanning the global landscape for anomalies, patterns, and untapped wisdom. Exploration is the first stage of evolution.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <DiscoverPanel 
          title="Global Architecture" 
          desc="Analyzing urban development and futuristic city planning models across diverse cultures." 
          icon="🌐" 
          tags={["URBAN", "PLANNING", "CULTURE"]} 
          telemetry="COORD_LINKED: 37.77 / -122.41 | DATA_DENSITY: HIGH"
        />
        <DiscoverPanel 
          title="Neural Frontiers" 
          desc="Exploring the intersection of human psychology and advanced artificial intelligence." 
          icon="🧠" 
          tags={["NEURO", "AI", "PSYCH"]} 
          telemetry="SYNAPSE_RATE: 4.2GHz | ENTROPY: 0.003%"
        />
        <DiscoverPanel 
          title="Cosmic Geometry" 
          desc="The search for mathematical perfection in the natural world and interstellar spaces." 
          icon="📐" 
          tags={["MATH", "SPACE", "LOGIC"]} 
          telemetry="VECTOR_PLANE: ALFA-9 | RATIO: 1.61803"
        />
      </div>

      <div className="bg-cyan-500/5 border border-cyan-500/20 p-8 rounded-lg relative overflow-hidden group">
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="w-full md:w-1/3 overflow-hidden rounded relative">
             <img src="https://picsum.photos/seed/discover/600/400" alt="Discovery" className="w-full h-48 object-cover rounded grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700 border border-cyan-500/30" />
             <div className="absolute inset-0 bg-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none mix-blend-overlay"></div>
          </div>
          <div className="flex-grow space-y-4">
            <h3 className="font-sci text-2xl group-hover:text-cyan-400 transition-colors">Current Expedition: PUNE METROPOLIS</h3>
            <p className="text-slate-400 leading-relaxed">
              Mapped as my primary node, Pune serves as the testing ground for my discoveries. I observe its rapid technological shifts, vibrant student culture, and its transformation into a global tech hub. Every street is a data stream.
            </p>
            <div className="flex gap-2">
              <span className="px-2 py-1 bg-cyan-950 text-cyan-400 text-[10px] font-mono border border-cyan-800 animate-pulse">ACTIVE_SCAN</span>
              <span className="px-2 py-1 bg-cyan-950 text-cyan-400 text-[10px] font-mono border border-cyan-800">DATA_MINING</span>
            </div>
          </div>
        </div>
        {/* Background Grid Pattern */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle, #22d3ee 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
      </div>
    </div>
  );
};

const DiscoverPanel: React.FC<{ title: string; desc: string; icon: string; tags: string[]; telemetry: string }> = ({ title, desc, icon, tags, telemetry }) => (
  <div className="p-6 border border-cyan-500/10 bg-slate-900/40 hover:bg-slate-900/80 transition-all group relative overflow-hidden h-64 flex flex-col justify-between">
    {/* Scanning Line on Hover */}
    <div className="absolute left-0 w-full h-0.5 bg-cyan-400/50 shadow-[0_0_10px_#22d3ee] top-0 opacity-0 group-hover:opacity-100 group-hover:animate-[scanline-internal_2s_linear_infinite] pointer-events-none"></div>

    <div>
      <div className="text-4xl mb-4 opacity-50 group-hover:opacity-100 group-hover:scale-110 transition-all duration-300">{icon}</div>
      <h3 className="font-sci text-xl mb-3 group-hover:text-cyan-400 transition-colors uppercase tracking-tight">{title}</h3>
      <p className="text-slate-400 text-sm leading-relaxed line-clamp-2 group-hover:line-clamp-none transition-all">{desc}</p>
    </div>

    <div className="relative overflow-hidden pt-4">
      <div className="flex flex-wrap gap-2 group-hover:translate-y-12 opacity-100 transition-all duration-300">
        {tags.map(t => (
          <span key={t} className="text-[8px] font-sci px-2 py-0.5 border border-cyan-500/20 text-cyan-500/60">{t}</span>
        ))}
      </div>
      
      {/* Telemetry reveal on hover */}
      <div className="absolute inset-0 flex items-center translate-y-full group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
        <div className="font-mono text-[9px] text-cyan-400/80 bg-cyan-400/5 p-2 border border-cyan-400/20 w-full">
          TELEMETRY: {telemetry}
        </div>
      </div>
    </div>

    <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-cyan-500/20 group-hover:border-cyan-400 transition-colors"></div>
    
    <style>{`
      @keyframes scanline-internal {
        0% { top: 0; }
        100% { top: 100%; }
      }
    `}</style>
  </div>
);

export default Discover;
