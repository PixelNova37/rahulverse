
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Hologram from './Hologram';

const Hero: React.FC = () => {
  // Synchronize with persistent storage
  const [profile, setProfile] = useState({
    fullName: 'RAHUL',
    designation: 'Student / Visionary',
    location: 'PUNE, IN',
    insta: 'rah_l.bfx'
  });

  useEffect(() => {
    const saved = localStorage.getItem('rahul_profile_core');
    if (saved) {
      const parsed = JSON.parse(saved);
      setProfile({
        fullName: parsed.fullName.toUpperCase(),
        designation: parsed.designation.toUpperCase(),
        location: parsed.location.split(',')[0].toUpperCase().trim() + ', IN',
        insta: parsed.insta
      });
    }
  }, []);

  return (
    <div className="space-y-12 py-10 md:py-20 animate-in fade-in slide-in-from-bottom-8 duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-sci uppercase tracking-[0.2em]">
              Subject Identification: {profile.fullName}
            </div>
            {/* Special Insta Badge */}
            <a 
              href={`https://instagram.com/${profile.insta}`} 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-3 py-1 bg-pink-600/10 border border-pink-500/30 text-pink-500 text-[10px] font-sci uppercase tracking-widest hover:bg-pink-500 hover:text-white transition-all animate-pulse flex items-center gap-2"
            >
              <span className="text-sm">📸</span> {profile.insta}
            </a>
          </div>
          <h1 className="font-sci text-6xl md:text-8xl font-black leading-tight tracking-tighter">
            DISCOVER<br />
            <span className="text-cyan-400 glow-cyan">INVENT</span><br />
            <span className="text-pink-500 glow-magenta">DESTROY</span>
          </h1>
          <p className="text-slate-400 text-lg max-w-lg leading-relaxed border-l-2 border-cyan-500/30 pl-6">
            A {profile.designation} from {profile.location}. Engineering the bridge between current reality and the futuristic horizon. 
            On a mission to decode the world, forge new possibilities, and eradicate the entropy of negativity.
          </p>
          <div className="flex flex-wrap gap-4 pt-4">
            <Link to="/contact" className="px-8 py-3 bg-cyan-500 text-slate-950 font-sci font-bold uppercase tracking-widest hover:bg-cyan-400 transition-colors shadow-[0_0_20px_rgba(34,211,238,0.4)]">
              JOIN THE MISSION
            </Link>
          </div>
        </div>

        {/* Visual Element: 3D Holographic Model */}
        <div className="relative flex justify-center items-center">
          <Hologram />
          
          {/* Decorative HUD Lines */}
          <div className="absolute top-0 left-0 md:-top-10 md:-left-10 w-20 h-20 border-t-2 border-l-2 border-cyan-500/40"></div>
          <div className="absolute bottom-0 right-0 md:-bottom-10 md:-right-10 w-20 h-20 border-b-2 border-r-2 border-pink-500/40"></div>
        </div>
      </div>

      {/* Metrics Section */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard label="Location" value={profile.location} sub="MH_REGION" />
        <MetricCard label="Status" value="STUDENT" sub="LEVEL: RESEARCHER" />
        <MetricCard label="Primary" value="INVENTION" sub="TYPE: FUTURE_TECH" />
        <MetricCard label="Neural_ID" value="BFX_CORE" sub={`@${profile.insta}`} />
      </div>
    </div>
  );
};

const MetricCard: React.FC<{ label: string; value: string; sub: string }> = ({ label, value, sub }) => (
  <div className="p-4 bg-slate-900/50 border border-cyan-500/10 hover:border-cyan-500/30 transition-colors group">
    <div className="text-[10px] text-cyan-400/60 uppercase tracking-widest font-sci mb-2">{label}</div>
    <div className={`text-xl md:text-2xl font-sci font-bold group-hover:text-cyan-400 transition-colors ${label === 'Neural_ID' ? 'text-pink-500 glow-magenta' : ''}`}>{value}</div>
    <div className={`text-[9px] text-slate-500 font-mono mt-1 ${label === 'Status' ? 'animate-pulse text-green-500' : ''}`}>{sub}</div>
  </div>
);

export default Hero;
