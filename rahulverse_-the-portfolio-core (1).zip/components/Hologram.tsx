
import React from 'react';

const Hologram: React.FC = () => {
  // Using a representative image URL that matches the user's provided character
  const characterImageUrl = "https://i.ibb.co/jkHy12Hh/image-5.png"; 

  return (
    <div className="relative w-full max-w-md aspect-[3/4] flex items-center justify-center perspective-[1000px]">
      {/* Projector Base */}
      <div className="absolute bottom-0 w-48 h-12 bg-cyan-900/20 rounded-[50%] border-2 border-cyan-500/40 shadow-[0_0_50px_rgba(34,211,238,0.3)] flex items-center justify-center">
        <div className="w-32 h-8 bg-cyan-500/10 rounded-[50%] border border-cyan-400/30 animate-pulse"></div>
        {/* Light Beams */}
        <div className="absolute -top-64 w-48 h-64 bg-gradient-to-t from-cyan-500/20 to-transparent clip-path-pyramid pointer-events-none"></div>
      </div>

      {/* Rotating Hologram Container */}
      <div className="relative w-full h-full flex items-center justify-center transform-style-3d animate-[hologram-rotate_12s_linear_infinite]">
        
        {/* Main Hologram Layer */}
        <div className="relative w-full h-[90%] flex items-center justify-center">
          <img 
            src={characterImageUrl}
            onError={(e) => {
               // Fallback if specific ID doesn't load
               e.currentTarget.src = "https://i.ibb.co/jkHy12Hh/image-5.png";
            }}
            alt="Rahul Hologram" 
            className="h-full object-contain filter drop-shadow-[0_0_15px_rgba(34,211,238,0.6)] brightness-125 contrast-125 opacity-90 hue-rotate-[180deg] saturate-150"
            style={{
               maskImage: 'linear-gradient(to bottom, black 80%, transparent 100%)',
               WebkitMaskImage: 'linear-gradient(to bottom, black 80%, transparent 100%)'
            }}
          />

          {/* Hologram Effects Overlay (Scanlines & Noise) */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
             <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]"></div>
             <div className="absolute top-0 left-0 w-full h-full animate-[hologram-glitch_4s_infinite] opacity-30 bg-cyan-400/10"></div>
          </div>
        </div>

        {/* Backside Mirror (to simulate 3D rotation better) */}
        <div className="absolute inset-0 flex items-center justify-center rotate-y-180 backface-hidden opacity-30">
           <img 
            src={characterImageUrl}
            alt="Rahul Hologram Back" 
            className="h-[90%] object-contain scale-x-[-1] blur-sm grayscale brightness-50"
          />
        </div>
      </div>

      {/* Floating UI Elements around the Hologram */}
      <div className="absolute top-10 right-0 p-2 border border-cyan-500/20 bg-slate-900/40 backdrop-blur-sm text-[8px] font-sci space-y-1">
        <div className="text-cyan-400">ID: RAHULVERSE_01</div>
        <div className="text-cyan-400/60">STATUS: RENDER_ACTIVE</div>
        <div className="w-16 h-1 bg-cyan-950">
           <div className="h-full bg-cyan-400 animate-[loading-bar_3s_infinite]"></div>
        </div>
      </div>

      <style>{`
        .transform-style-3d { transform-style: preserve-3d; }
        .rotate-y-180 { transform: rotateY(180deg); }
        .backface-hidden { backface-visibility: hidden; }
        
        @keyframes hologram-rotate {
          from { transform: rotateY(0deg); }
          to { transform: rotateY(360deg); }
        }

        @keyframes hologram-glitch {
          0% { transform: translateY(0); }
          1% { transform: translateY(-5px) skewX(20deg); }
          2% { transform: translateY(0) skewX(0); }
          50% { transform: translateY(0); }
          51% { transform: translateY(2px) scaleY(1.1); }
          52% { transform: translateY(0) scaleY(1); }
          100% { transform: translateY(0); }
        }

        @keyframes loading-bar {
          0% { width: 0%; }
          50% { width: 100%; }
          100% { width: 0%; }
        }

        .clip-path-pyramid {
          clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
        }
      `}</style>
    </div>
  );
};

export default Hologram;
