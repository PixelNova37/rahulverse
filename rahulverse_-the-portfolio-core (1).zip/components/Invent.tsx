
import React from 'react';

const Invent: React.FC = () => {
  return (
    <div className="space-y-12 py-10 animate-in fade-in slide-in-from-right-12 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-cyan-500/20 pb-8">
        <div className="space-y-2">
          <h2 className="font-sci text-5xl md:text-7xl font-black text-cyan-400 glow-cyan">INVENT</h2>
          <p className="text-slate-400 font-mono text-sm uppercase tracking-widest">
            Fabricating solutions for tomorrow's challenges. If it doesn't exist, I manifest it.
          </p>
        </div>
        <div className="text-right">
          <div className="text-[10px] text-cyan-400/40 font-sci">INVENTION_QUOTA</div>
          <div className="w-48 h-2 bg-slate-900 border border-cyan-500/30 relative">
            <div className="absolute top-0 left-0 h-full bg-cyan-400 animate-[pulse-bar_2s_infinite]" style={{ width: '85%' }}></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <ProjectCard 
          title="Nova-X Interface" 
          status="BETA" 
          desc="A neural-link inspired AI assistant designed to handle personal data organization and predictive planning." 
          tech={["React", "Gemini API", "Tailwind"]}
          img="https://picsum.photos/seed/novax/800/600"
        />
        <ProjectCard 
          title="Entropy Shield" 
          status="PROTOTYPE" 
          desc="Algorithm-based content filter that cleanses social feeds of low-frequency, toxic data points." 
          tech={["Python", "NLP", "TensorFlow"]}
          img="https://picsum.photos/seed/entropy/800/600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-8 border border-cyan-500/10 bg-slate-900/40 relative group overflow-hidden">
          {/* Subtle blueprint grid on hover */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity pointer-events-none" style={{ backgroundImage: 'linear-gradient(#22d3ee 1px, transparent 1px), linear-gradient(90deg, #22d3ee 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
          
          <h3 className="font-sci text-2xl mb-4 group-hover:text-cyan-400 transition-colors">THE FUTURE CORE</h3>
          <p className="text-slate-400 leading-relaxed mb-6">
            My engineering philosophy revolves around "Modular Reality." I believe the future isn't a single destination but a series of upgradable systems. From software to lifestyle, everything I invent is built to be iterated, scaled, and eventually... integrated into a larger global consciousness.
          </p>
          <button className="px-6 py-2 border border-cyan-500 text-cyan-400 font-sci text-xs hover:bg-cyan-500 hover:text-slate-950 transition-all hover-shake">
            VIEW DESIGN DOCS
          </button>
        </div>
        <div className="p-8 border border-pink-500/10 bg-slate-900/40 flex flex-col items-center justify-center text-center space-y-4 group hover:border-pink-500/40 transition-all cursor-wait">
          <div className="w-20 h-20 border-2 border-pink-500/30 rounded-full flex items-center justify-center animate-pulse group-hover:rotate-180 transition-transform duration-1000">
            <span className="text-3xl group-hover:scale-125 transition-transform">⚡</span>
          </div>
          <div className="font-sci text-lg text-pink-500 uppercase tracking-tighter">Powering Up</div>
          <p className="text-[10px] text-slate-500 font-mono">NEXT INNOVATION REVEAL IN: 04d 12h 44m</p>
          <div className="flex gap-1">
             {[1,2,3,4].map(i => <div key={i} className="w-2 h-0.5 bg-pink-500/20 group-hover:bg-pink-500 transition-colors" style={{ transitionDelay: `${i*100}ms` }}></div>)}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes pulse-bar {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }
        @keyframes scan-down {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(400%); }
        }
      `}</style>
    </div>
  );
};

const ProjectCard: React.FC<{ title: string; status: string; desc: string; tech: string[]; img: string }> = ({ title, status, desc, tech, img }) => (
  <div className="group relative cursor-crosshair">
    <div className="relative overflow-hidden aspect-video border border-cyan-500/20 group-hover:border-cyan-500/80 group-hover:shadow-[0_0_30px_rgba(34,211,238,0.25)] transition-all duration-500">
      <img 
        src={img} 
        alt={title} 
        className="w-full h-full object-cover grayscale opacity-50 group-hover:grayscale-0 group-hover:opacity-100 group-hover:scale-105 group-hover:brightness-110 transition-all duration-1000" 
      />
      
      {/* Blueprint Overlay on Hover */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
      
      {/* Subtle Data Scan Animation on Hover */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none overflow-hidden">
        <div className="w-full h-[2px] bg-cyan-400/40 absolute top-0 animate-[scan-down_2.5s_linear_infinite] shadow-[0_0_12px_rgba(34,211,238,0.8)]"></div>
        <div className="absolute inset-0 bg-cyan-400/5 mix-blend-overlay"></div>
      </div>

      <div className="absolute top-4 right-4 bg-slate-950/80 px-2 py-1 text-[8px] font-sci text-cyan-400 border border-cyan-400/50 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-colors z-10">
        STATUS: {status}
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60"></div>
    </div>
    <div className="mt-4 space-y-2">
      <h3 className="font-sci text-xl text-cyan-400 group-hover:glow-cyan transition-all group-hover:translate-x-2">{title}</h3>
      <p className="text-slate-400 text-sm leading-relaxed group-hover:text-slate-300 transition-colors">{desc}</p>
      <div className="flex gap-3 pt-2">
        {tech.map((t, i) => (
          <span key={t} className="text-[10px] font-mono text-cyan-500/60 group-hover:text-cyan-400 transition-all" style={{ transitionDelay: `${i*50}ms` }}>#{t}</span>
        ))}
      </div>
    </div>
  </div>
);

export default Invent;
