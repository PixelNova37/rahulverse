
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useCart } from '../App';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const { cartCount, wishlistCount } = useCart();

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="h-screen bg-slate-950 text-cyan-50 relative overflow-y-auto flex flex-col">
      {/* HUD Borders */}
      <div className="fixed top-0 left-0 w-full h-1 bg-cyan-500/30 z-[110]"></div>
      <div className="fixed bottom-0 left-0 w-full h-1 bg-cyan-500/30 z-[110]"></div>
      <div className="fixed top-0 left-0 h-full w-1 bg-cyan-500/30 z-[110]"></div>
      <div className="fixed top-0 right-0 h-full w-1 bg-cyan-500/30 z-[110]"></div>

      {/* Header */}
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-cyan-500/20 p-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 border-2 border-cyan-400 rotate-45 flex items-center justify-center group-hover:rotate-180 transition-transform duration-700">
              <span className="font-bold -rotate-45 text-cyan-400 group-hover:rotate-[135deg] transition-transform">R</span>
            </div>
            <div className="flex flex-col">
              <span className="font-sci text-xl tracking-tighter glow-cyan">RAHULVERSE_v1.0</span>
              <span className="text-[10px] text-cyan-400/60 uppercase tracking-widest">Region: INDIA_NODE</span>
            </div>
          </Link>

          <nav className="flex items-center gap-1 md:gap-6 overflow-x-auto max-w-full pb-2 md:pb-0">
            <NavLink to="/" active={isActive('/')}>STATUS</NavLink>
            <NavLink to="/discover" active={isActive('/discover')}>DISCOVER</NavLink>
            <NavLink to="/invent" active={isActive('/invent')}>INVENT</NavLink>
            <NavLink to="/destroy" active={isActive('/destroy')}>DESTROY</NavLink>
            <NavLink to="/market" active={isActive('/market')}>MARKET</NavLink>
            
            <Link 
              to="/wishlist" 
              className={`relative px-3 py-1 font-sci text-xs transition-all duration-300 border-b-2 whitespace-nowrap flex items-center gap-2 ${
                isActive('/wishlist') ? 'border-cyan-400 text-cyan-400 glow-cyan' : 'border-transparent text-slate-500 hover:text-cyan-300'
              }`}
            >
              ARCHIVE
              {wishlistCount > 0 && (
                <span className="bg-cyan-600 text-[8px] text-white px-1.5 py-0.5 rounded-full">
                  {wishlistCount}
                </span>
              )}
            </Link>

            <Link 
              to="/cart" 
              className={`relative px-3 py-1 font-sci text-xs transition-all duration-300 border-b-2 whitespace-nowrap flex items-center gap-2 ${
                isActive('/cart') ? 'border-cyan-400 text-cyan-400 glow-cyan' : 'border-transparent text-slate-500 hover:text-cyan-300'
              }`}
            >
              MANIFEST
              {cartCount > 0 && (
                <span className="bg-pink-600 text-[8px] text-white px-1.5 py-0.5 rounded-full animate-pulse">
                  {cartCount}
                </span>
              )}
            </Link>
            <NavLink to="/contact" active={isActive('/contact')}>UPLINK</NavLink>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow relative">
        <div className="max-w-7xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>

      {/* Footer / Status Bar */}
      <footer className="border-t border-cyan-500/20 p-3 text-[10px] uppercase tracking-widest text-cyan-400/40 flex justify-between z-40 bg-slate-950">
        <div className="flex gap-4">
          <span>LOC: PUNE_MH_IND // LAT: 18.5204 // LNG: 73.8567</span>
          <Link to="/admin" className="hover:text-cyan-400 transition-colors border-l border-cyan-900/50 pl-4">[ADMIN_UPLINK]</Link>
        </div>
        <span className="animate-pulse">CONNECTED TO BHARAT_SERVER_01</span>
      </footer>
    </div>
  );
};

const NavLink: React.FC<{ to: string; active: boolean; children: React.ReactNode }> = ({ to, active, children }) => (
  <Link
    to={to}
    className={`px-3 py-1 font-sci text-xs transition-all duration-300 border-b-2 whitespace-nowrap ${
      active 
        ? 'border-cyan-400 text-cyan-400 glow-cyan' 
        : 'border-transparent text-slate-500 hover:text-cyan-300'
    }`}
  >
    {children}
  </Link>
);

export default Layout;
