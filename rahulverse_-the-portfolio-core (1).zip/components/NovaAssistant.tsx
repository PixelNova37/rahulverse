
import React, { useState, useRef, useEffect } from 'react';
import { chatWithNova } from '../services/geminiService';
import { Message } from '../types';

const NovaAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'ai', content: 'Nova-X online. Uplink established. How can I assist your discovery today?', timestamp: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: input, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    const response = await chatWithNova(input);
    const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'ai', content: response || "ERROR", timestamp: new Date() };
    setMessages(prev => [...prev, aiMsg]);
    setIsTyping(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Floating Toggle Button */}
      {!isOpen && (
        <button 
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-cyan-500 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.6)] animate-pulse border-4 border-slate-950 hover:scale-110 transition-transform"
        >
          <span className="text-2xl">🤖</span>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="w-[350px] md:w-[400px] h-[500px] bg-slate-900 border-2 border-cyan-500 shadow-2xl flex flex-col rounded-xl overflow-hidden animate-in zoom-in-95 duration-200">
          <div className="bg-cyan-500 p-3 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-slate-950 rounded-full animate-ping"></div>
              <span className="font-sci text-slate-950 font-bold tracking-widest text-xs">NOVA-X // ASSISTANT</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-slate-950 font-bold hover:bg-slate-950/20 px-2 rounded">×</button>
          </div>

          <div ref={scrollRef} className="flex-grow p-4 overflow-y-auto space-y-4 font-mono text-sm scrollbar-hide">
            {messages.map(msg => (
              <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-lg border ${
                  msg.role === 'user' 
                    ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-50' 
                    : 'bg-slate-800 border-slate-700 text-slate-200'
                }`}>
                  <div className="text-[8px] uppercase tracking-widest mb-1 opacity-40">{msg.role}</div>
                  {msg.content}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-slate-800 border border-slate-700 p-3 rounded-lg text-cyan-400 animate-pulse text-[10px] font-sci">
                  DECRYPTING_RESPONSE...
                </div>
              </div>
            )}
          </div>

          <div className="p-3 border-t border-slate-800 bg-slate-950 flex gap-2">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Query the core..."
              className="flex-grow bg-slate-900 border border-slate-800 p-2 text-cyan-400 focus:outline-none focus:border-cyan-500 font-mono text-sm"
            />
            <button 
              onClick={handleSend}
              className="px-4 bg-cyan-500 text-slate-950 font-sci text-xs font-bold hover:bg-cyan-400 transition-colors"
            >
              SEND
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default NovaAssistant;
