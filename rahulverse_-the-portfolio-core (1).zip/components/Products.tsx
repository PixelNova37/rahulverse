
import React, { useState } from 'react';
import { useCart } from '../App';

interface Product {
  id: string;
  name: string;
  price: string;
  priceNum: number;
  description: string;
  category: 'HARDWARE' | 'SOFTWARE' | 'ASSET';
  image: string;
  specs: string[];
  stock: number;
}

const PRODUCT_DATA: Product[] = [
  {
    id: 'RV-001',
    name: 'NEURAL_LINK_v1.0',
    price: '₹45,000',
    priceNum: 45000,
    description: 'Direct consciousness-to-code interface. Built for high-frequency inventors.',
    category: 'HARDWARE',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800',
    specs: ['SYNAPSE_LATENCY: < 1ms', 'ENCRYPTION: AES-512', 'COMPATIBILITY: HUMAN_V2'],
    stock: 12
  },
  {
    id: 'RV-002',
    name: 'ENTROPY_PURGE_CORE',
    price: '₹9,500',
    priceNum: 9500,
    description: 'A physical device that emits negative entropy waves to cleanse your workspace.',
    category: 'ASSET',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=800',
    specs: ['RANGE: 15m RADIUS', 'POWER: DARK_MATTER', 'LIFE: 5000_CYCLES'],
    stock: 5
  },
  {
    id: 'RV-003',
    name: 'DISCOVERY_DRONE_MOD',
    price: '₹24,999',
    priceNum: 24999,
    description: 'Custom firmware for mapping urban anomalies. Auto-links to Rahulverse cloud.',
    category: 'SOFTWARE',
    image: 'https://images.unsplash.com/photo-1508614589041-895b88991e3e?auto=format&fit=crop&q=80&w=800',
    specs: ['AI_PILOT: ALPHA_9', 'NIGHT_VISION: TRUE', 'DATA_BANDWIDTH: 10GB/S'],
    stock: 24
  },
  {
    id: 'RV-004',
    name: 'VISIONARY_SHADER_PACK',
    price: '₹3,999',
    priceNum: 3999,
    description: 'A collection of UI shaders for futuristic web development. As seen in Rahulverse.',
    category: 'SOFTWARE',
    image: 'https://images.unsplash.com/photo-1614728263952-84ea206f99b6?auto=format&fit=crop&q=80&w=800',
    specs: ['FRAMEWORK: REACT_GL', 'FX: CRT_GLITCH', 'SIZE: 250MB'],
    stock: 999
  }
];

const Products: React.FC = () => {
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const [addedId, setAddedId] = useState<string | null>(null);

  const handleAdd = (product: Product) => {
    addToCart(product);
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 2000);
  };

  return (
    <div className="space-y-12 py-10 animate-in fade-in slide-in-from-bottom-12 duration-500">
      <div className="text-center space-y-4">
        <div className="inline-block px-4 py-1 border border-cyan-500/30 bg-cyan-500/5 text-cyan-400 text-[10px] font-sci tracking-[0.4em] uppercase">
          Marketplace // Indian Node (₹)
        </div>
        <h2 className="font-sci text-5xl md:text-7xl font-black text-cyan-400 glow-cyan">THE MARKET</h2>
        <p className="text-slate-400 max-w-2xl mx-auto font-mono text-sm uppercase tracking-widest leading-relaxed">
          Secure Indian gateway active. Procure the tools used by the collective. 
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {PRODUCT_DATA.map((product) => (
          <div 
            key={product.id}
            className="group relative bg-slate-900 border border-cyan-500/20 hover:border-cyan-500 transition-all duration-300 flex flex-col"
          >
            {/* Image Section */}
            <div className="relative aspect-square overflow-hidden bg-black">
              <img 
                src={product.image} 
                alt={product.name} 
                loading="lazy"
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700 opacity-60 group-hover:opacity-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80"></div>
              
              <div className="absolute top-3 left-3 px-2 py-0.5 bg-cyan-500/20 border border-cyan-500/40 text-[8px] font-sci text-cyan-300 uppercase tracking-widest">
                {product.category}
              </div>

              {/* Wishlist Button Overlay */}
              <button 
                onClick={() => toggleWishlist(product)}
                className={`absolute top-3 right-3 w-8 h-8 rounded-full border flex items-center justify-center transition-all ${
                  isInWishlist(product.id) 
                    ? 'bg-cyan-500 border-cyan-400 text-slate-950 shadow-[0_0_10px_rgba(34,211,238,0.8)]' 
                    : 'bg-slate-950/60 border-cyan-500/30 text-cyan-500/60 hover:border-cyan-400 hover:text-cyan-400'
                }`}
                title={isInWishlist(product.id) ? "Remove from Archive" : "Archive Asset"}
              >
                {isInWishlist(product.id) ? '★' : '☆'}
              </button>

              <div className="absolute bottom-3 right-3 font-sci text-lg text-cyan-400 glow-cyan">
                {product.price}
              </div>
            </div>

            <div className="p-5 flex-grow space-y-3">
              <div className="text-[9px] font-mono text-slate-500 tracking-tighter uppercase">{product.id} // STOCK: {product.stock}</div>
              <h3 className="font-sci text-lg text-slate-100 group-hover:text-cyan-400 transition-colors uppercase leading-tight">
                {product.name}
              </h3>
              <p className="text-slate-400 text-xs leading-relaxed line-clamp-2">
                {product.description}
              </p>
              
              <div className="pt-2 border-t border-cyan-500/10 space-y-1">
                {product.specs.map((spec, i) => (
                  <div key={i} className="text-[8px] font-mono text-cyan-500/60 flex items-center gap-2">
                    <span className="w-1 h-1 bg-cyan-500/40 rounded-full"></span>
                    {spec}
                  </div>
                ))}
              </div>
            </div>

            <button 
              onClick={() => handleAdd(product)}
              className={`w-full py-3 border-t font-sci text-xs font-bold uppercase tracking-widest transition-all ${
                addedId === product.id 
                  ? 'bg-green-500/20 border-green-500 text-green-400' 
                  : 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950'
              }`}
            >
              {addedId === product.id ? 'ADDED_TO_MANIFEST' : 'LOAD_TO_BUFFER'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Products;
