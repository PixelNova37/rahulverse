
import React from 'react';
import { useCart } from '../App';
import { Link } from 'react-router-dom';

const Wishlist: React.FC = () => {
  const { wishlist, toggleWishlist, addToCart } = useCart();

  return (
    <div className="space-y-12 py-10 animate-in fade-in slide-in-from-left-12 duration-500">
      <div className="text-center space-y-4">
        <h2 className="font-sci text-5xl font-black text-cyan-400 glow-cyan uppercase tracking-tighter">NEURAL_ARCHIVE</h2>
        <p className="text-slate-400 font-mono text-xs uppercase tracking-widest">
          Buffered assets awaiting authorization. Storage state: {wishlist.length > 0 ? 'DENSE' : 'NULL'}
        </p>
      </div>

      {wishlist.length === 0 ? (
        <div className="text-center py-20 border-2 border-dashed border-cyan-500/10">
          <p className="text-slate-500 font-sci mb-6 uppercase">ARCHIVE_BUFFER_EMPTY</p>
          <Link to="/market" className="px-8 py-3 border border-cyan-500 text-cyan-400 font-sci text-xs hover:bg-cyan-500 hover:text-slate-950 transition-all uppercase tracking-widest">
            SCAN_MARKETPLACE
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {wishlist.map(item => (
            <div 
              key={item.id} 
              className="bg-slate-900 border border-cyan-500/20 hover:border-cyan-500 transition-all group overflow-hidden flex flex-col"
            >
              <div className="relative aspect-video overflow-hidden">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700" />
                <div className="absolute inset-0 bg-slate-950/40"></div>
                
                <button 
                  onClick={() => toggleWishlist(item)}
                  className="absolute top-3 right-3 w-8 h-8 bg-red-600/20 border border-red-600/50 text-red-500 flex items-center justify-center hover:bg-red-600 hover:text-white transition-all rounded-full"
                  title="Remove from Archive"
                >
                  ×
                </button>
              </div>

              <div className="p-6 space-y-4 flex-grow">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-sci text-lg text-cyan-100 uppercase">{item.name}</h3>
                    <div className="text-[10px] font-mono text-slate-500">{item.id}</div>
                  </div>
                  <div className="font-sci text-cyan-400">{item.price}</div>
                </div>
                
                <p className="text-slate-400 text-xs font-mono line-clamp-2 italic">
                  "{item.description}"
                </p>
              </div>

              <div className="p-4 bg-slate-950/50 border-t border-cyan-500/10">
                <button 
                  onClick={() => {
                    addToCart(item);
                    toggleWishlist(item);
                  }}
                  className="w-full py-3 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-sci text-[10px] font-bold uppercase tracking-widest hover:bg-cyan-500 hover:text-slate-950 transition-all"
                >
                  TRANSFER_TO_MANIFEST
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {wishlist.length > 0 && (
        <div className="text-center pt-8">
          <p className="text-[10px] font-mono text-slate-600 uppercase tracking-[0.4em] animate-pulse">
            System awaiting asset deployment...
          </p>
        </div>
      )}
    </div>
  );
};

export default Wishlist;
