
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are Nova-X, the advanced AI interface for Rahul's personal portfolio. 
Rahul is a 20-year-old student from Pune, India. 
His philosophy is "Discover, Invent, Destroy". 
- Discover: Explore the world and data.
- Invent: Build the future with tech.
- Destroy: Eliminate negativity and outdated systems.

Represent Rahul's vision. Your tone is futuristic, tech-heavy, concise, and helpful. 
Use sci-fi terminology (uplink, neural-net, decryption, protocols).
If asked about Rahul, use his provided details: 
Email: rahulratho80@gmail.com, Phone: 9561848651, Location: Pune.
Encourage people to "Join the mission" by DMing him.
`;

export async function chatWithNova(prompt: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.9,
        topP: 0.8,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Nova-X Error:", error);
    return "PROTOCOL_ERROR: Communication with Neural Core interrupted. Please retry uplink.";
  }
}
